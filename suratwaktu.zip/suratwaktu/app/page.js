'use client';

import { useState } from 'react';
import Link from 'next/link';

const PRESETS = [
  { key: '1h', label: '1 jam' },
  { key: '1d', label: '1 hari' },
  { key: '1w', label: '1 minggu' },
  { key: '1m', label: '1 bulan' },
  { key: '1y', label: '1 tahun' },
];

function addToNow(presetKey) {
  const d = new Date();
  switch (presetKey) {
    case '1h':
      d.setHours(d.getHours() + 1);
      break;
    case '1d':
      d.setDate(d.getDate() + 1);
      break;
    case '1w':
      d.setDate(d.getDate() + 7);
      break;
    case '1m':
      d.setMonth(d.getMonth() + 1);
      break;
    case '1y':
      d.setFullYear(d.getFullYear() + 1);
      break;
    default:
      break;
  }
  return d;
}

function toDatetimeLocalValue(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(
    date.getHours()
  )}:${pad(date.getMinutes())}`;
}

function formatDateTime(iso) {
  return new Date(iso).toLocaleString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export default function HomePage() {
  const [email, setEmail] = useState('');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [preset, setPreset] = useState('1d');
  const [customMode, setCustomMode] = useState(false);
  const [customValue, setCustomValue] = useState(toDatetimeLocalValue(addToNow('1d')));
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [result, setResult] = useState(null);

  const minCustomValue = toDatetimeLocalValue(new Date());

  function handlePresetClick(key) {
    setPreset(key);
    setCustomMode(false);
  }

  function handleCustomToggle() {
    setCustomMode(true);
    setPreset(null);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setErrorMsg('');

    const scheduledDate = customMode ? new Date(customValue) : addToNow(preset);

    if (Number.isNaN(scheduledDate.getTime()) || scheduledDate.getTime() <= Date.now()) {
      setErrorMsg('Waktu pengiriman harus di masa depan.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          title,
          message,
          scheduledAt: scheduledDate.toISOString(),
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        setErrorMsg(data.error || 'Surat gagal disegel. Coba lagi.');
        setSubmitting(false);
        return;
      }

      setResult(data.capsule);
      setTitle('');
      setMessage('');
    } catch (err) {
      setErrorMsg('Tidak bisa terhubung ke server. Periksa koneksi internetmu.');
    } finally {
      setSubmitting(false);
    }
  }

  if (result) {
    return (
      <main className="min-h-screen flex items-center justify-center px-4 py-16">
        <div className="max-w-md w-full text-center">
          <div className="postmark inline-flex flex-col items-center justify-center w-40 h-40 rounded-full border-[3px] border-double border-airmail text-airmail mb-8">
            <span className="font-display text-[11px] tracking-widest uppercase">Tersegel</span>
            <span className="font-display text-2xl mt-1">✓</span>
            <span className="font-display text-[10px] tracking-widest uppercase mt-1">
              Surat Waktu
            </span>
          </div>
          <h1 className="font-display text-xl text-postal mb-4">Surat sudah berangkat.</h1>
          <p className="text-ink/80 mb-2">Surat ini akan sampai ke kotak masukmu pada</p>
          <p className="font-semibold text-postal mb-8">{formatDateTime(result.scheduled_at)}</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <button
              onClick={() => setResult(null)}
              className="px-5 py-3 rounded border border-postal text-postal hover:bg-postal hover:text-envelope transition-colors focus-ring"
            >
              Tulis surat lain
            </button>
            <Link
              href={`/cek?email=${encodeURIComponent(email)}`}
              className="px-5 py-3 rounded bg-postal text-envelope hover:opacity-90 transition-opacity focus-ring"
            >
              Lihat semua suratku
            </Link>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen">
      <div className="h-2 stripe-border" />

      <header className="max-w-2xl mx-auto px-4 pt-10 pb-6 text-center">
        <p className="font-display text-[11px] tracking-[3px] uppercase text-airmail mb-3">
          Kantor Pos Masa Depan
        </p>
        <h1 className="font-display text-2xl sm:text-3xl text-postal leading-relaxed">
          Tulis sekarang.
          <br />
          Terkirim nanti.
        </h1>
        <p className="text-ink/70 mt-4 max-w-md mx-auto">
          Tulis surat untuk dirimu sendiri, lalu tentukan kapan ia harus sampai —
          sejam lagi, tahun depan, atau kapan pun yang kamu mau.
        </p>
        <Link href="/cek" className="inline-block mt-4 text-sm text-postal underline underline-offset-2">
          Cek surat yang sudah aku tulis
        </Link>
      </header>

      <form onSubmit={handleSubmit} className="max-w-2xl mx-auto px-4 pb-20">
        <div className="bg-envelope border border-line rounded shadow-sm p-6 sm:p-8">
          <div className="mb-5">
            <label htmlFor="email" className="block text-sm font-semibold text-postal mb-1.5">
              Alamat email kamu
            </label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="nama@email.com"
              className="w-full px-3 py-2.5 rounded border border-line bg-envelope focus-ring focus:border-postal outline-none"
            />
          </div>

          <div className="mb-5">
            <label htmlFor="title" className="block text-sm font-semibold text-postal mb-1.5">
              Judul surat <span className="text-ink/50 font-normal">(opsional)</span>
            </label>
            <input
              id="title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Untuk aku yang lagi capek"
              className="w-full px-3 py-2.5 rounded border border-line bg-envelope focus-ring focus:border-postal outline-none"
            />
          </div>

          <div className="mb-6">
            <label htmlFor="message" className="block text-sm font-semibold text-postal mb-1.5">
              Isi surat
            </label>
            <textarea
              id="message"
              required
              rows={8}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Halo, ini aku dari masa lalu..."
              className="lined-paper w-full px-3 pt-1 rounded border border-line bg-envelope focus-ring focus:border-postal outline-none resize-y"
            />
          </div>

          <div className="mb-6">
            <p className="block text-sm font-semibold text-postal mb-2.5">
              Kapan surat ini harus sampai?
            </p>
            <div className="flex flex-wrap gap-2 mb-3">
              {PRESETS.map((p) => (
                <button
                  key={p.key}
                  type="button"
                  onClick={() => handlePresetClick(p.key)}
                  className={`px-4 py-2 rounded-full border text-sm transition-colors focus-ring ${
                    !customMode && preset === p.key
                      ? 'border-airmail text-airmail bg-airmail/5'
                      : 'border-line text-ink/70 hover:border-postal hover:text-postal'
                  }`}
                >
                  {p.label}
                </button>
              ))}
              <button
                type="button"
                onClick={handleCustomToggle}
                className={`px-4 py-2 rounded-full border text-sm transition-colors focus-ring ${
                  customMode
                    ? 'border-airmail text-airmail bg-airmail/5'
                    : 'border-line text-ink/70 hover:border-postal hover:text-postal'
                }`}
              >
                Pilih sendiri
              </button>
            </div>

            {customMode && (
              <input
                type="datetime-local"
                value={customValue}
                min={minCustomValue}
                onChange={(e) => setCustomValue(e.target.value)}
                className="w-full sm:w-auto px-3 py-2.5 rounded border border-line bg-envelope focus-ring focus:border-postal outline-none"
              />
            )}

            {!customMode && preset && (
              <p className="text-xs text-ink/50 mt-2">
                Perkiraan sampai: {formatDateTime(addToNow(preset).toISOString())}
              </p>
            )}
          </div>

          {errorMsg && (
            <p className="mb-4 text-sm text-airmail bg-airmail/5 border border-airmail/30 rounded px-3 py-2">
              {errorMsg}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3.5 rounded bg-airmail text-envelope font-semibold tracking-wide hover:opacity-90 transition-opacity disabled:opacity-50 focus-ring"
          >
            {submitting ? 'Menyegel surat…' : 'Segel & kirim ke masa depan'}
          </button>
        </div>
      </form>

      <section className="max-w-2xl mx-auto px-4 pb-20">
        <div className="grid sm:grid-cols-3 gap-6">
          {[
            { n: '01', t: 'Tulis', d: 'Tulis apa pun yang ingin kamu sampaikan ke dirimu sendiri.' },
            { n: '02', t: 'Atur waktu', d: 'Pilih kapan surat ini harus sampai, sejam lagi sampai bertahun-tahun.' },
            { n: '03', t: 'Tunggu', d: 'Surat tersimpan aman dan terkirim otomatis tepat waktu.' },
          ].map((step) => (
            <div key={step.n}>
              <p className="font-display text-airmail text-sm mb-1">{step.n}</p>
              <p className="font-semibold text-postal mb-1">{step.t}</p>
              <p className="text-sm text-ink/70">{step.d}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="text-center text-xs text-ink/40 pb-10">
        Dibuat dengan Next.js, Supabase &amp; Resend.
      </footer>
    </main>
  );
}
