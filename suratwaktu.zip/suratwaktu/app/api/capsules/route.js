import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const email = searchParams.get('email');

  if (!email) {
    return NextResponse.json({ error: 'Masukkan alamat email.' }, { status: 400 });
  }

  const { data, error } = await supabase
    .from('capsules')
    .select('id, title, scheduled_at, created_at, sent, sent_at')
    .eq('email', email)
    .order('scheduled_at', { ascending: true });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ capsules: data });
}
