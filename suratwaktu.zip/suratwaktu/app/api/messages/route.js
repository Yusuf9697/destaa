import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';

export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Data yang dikirim tidak valid.' }, { status: 400 });
  }

  const { email, title, message, scheduledAt } = body || {};

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return NextResponse.json({ error: 'Masukkan alamat email yang valid.' }, { status: 400 });
  }

  if (!message || !message.trim()) {
    return NextResponse.json({ error: 'Isi surat tidak boleh kosong.' }, { status: 400 });
  }

  if (!scheduledAt) {
    return NextResponse.json({ error: 'Pilih kapan surat ini harus sampai.' }, { status: 400 });
  }

  const scheduledDate = new Date(scheduledAt);
  if (Number.isNaN(scheduledDate.getTime()) || scheduledDate.getTime() <= Date.now()) {
    return NextResponse.json({ error: 'Waktu pengiriman harus di masa depan.' }, { status: 400 });
  }

  const { data, error } = await supabase
    .from('capsules')
    .insert({
      email,
      title: title && title.trim() ? title.trim() : null,
      message: message.trim(),
      scheduled_at: scheduledDate.toISOString(),
    })
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ capsule: data });
}
