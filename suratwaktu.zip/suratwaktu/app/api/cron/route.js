import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { resend } from '@/lib/resend';
import { buildEmailHtml } from '@/lib/email-template';

// Endpoint ini dipanggil secara berkala oleh layanan penjadwal luar
// (contoh: cron-job.org) lewat URL:
//   https://domain-kamu.vercel.app/api/cron?secret=ISI_CRON_SECRET
// Setiap kali dipanggil, ia mencari surat yang sudah waktunya terkirim
// dan mengirimkannya lewat Resend.
export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const secret = searchParams.get('secret');

  if (!process.env.CRON_SECRET || secret !== process.env.CRON_SECRET) {
    return NextResponse.json({ error: 'Tidak diizinkan.' }, { status: 401 });
  }

  const nowIso = new Date().toISOString();

  const { data: dueCapsules, error } = await supabase
    .from('capsules')
    .select('*')
    .eq('sent', false)
    .lte('scheduled_at', nowIso);

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  let sentCount = 0;
  const failures = [];

  for (const capsule of dueCapsules || []) {
    try {
      await resend.emails.send({
        from: process.env.EMAIL_FROM || 'SuratWaktu <onboarding@resend.dev>',
        to: capsule.email,
        subject: capsule.title
          ? `✉️ ${capsule.title}`
          : '✉️ Surat dari masa lalu, untukmu hari ini',
        html: buildEmailHtml(capsule),
      });

      await supabase
        .from('capsules')
        .update({ sent: true, sent_at: new Date().toISOString() })
        .eq('id', capsule.id);

      sentCount += 1;
    } catch (err) {
      failures.push({ id: capsule.id, error: err.message });
    }
  }

  return NextResponse.json({
    checked: (dueCapsules || []).length,
    sent: sentCount,
    failures,
  });
}
