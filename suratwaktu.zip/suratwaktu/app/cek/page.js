'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';

function formatDateTime(iso) {
  return new Date(iso).toLocaleString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function CekContent() {
  const searchParams = useSearchParams();
  const [email, setEmail] = useState(searchParams.get('email') || '');
  const [capsules, setCapsules] = useState(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  async function fetchCapsules(e) {
    if (e) e.preventDefault();
    if (!email) return;
    setLoading(true);
    setErrorMsg('');
    try {
      const res = await fetch(`/api/capsules?email=${encodeURIComponent(email)}`);
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || 'Gagal mengambil data surat.');
        setCapsules(null);
      } else {
        setCapsules(data.capsules);
      }
    } catch {
      setErrorMsg('Tidak bisa terhubung ke server.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (searchParams.get('email')) {
      fetchCapsules();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <main className="min-h-screen">
      <div className="h-2 stripe-border" />

      <header className="max-w-2xl mx-auto px-4 pt-10 pb-6 text-center">
        <p className="font-display text-[11px] tracking-[3px] uppercase text-airmail mb-3">
          Kantor Pos Masa Depan
        </p>
        <h1 className="font-display text-2xl text-postal">Cek surat saya</h1>
        <p className="text-ink/70 mt-3">
          Masukkan email yang kamu pakai saat menulis surat untuk melihat statusnya.
        </p>
        <Link href="/" className="inline-block mt-4 text-sm text-postal underline underline-offset-2">
          ← Tulis surat baru
        </Link>
      </header>

      <form onSubmit={fetchCapsules} className="max-w-2xl mx-auto px-4 mb-8">
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="nama@email.com"
            className="flex-1 px-3 py-2.5 rounded border border-line bg-envelope focus-ring focus:border-postal outline-none"
          />
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2.5 rounded bg-postal text-envelope font-semibold hover:opacity-90 transition-opacity disabled:opacity-50 focus-ring"
          >
            {loading ? 'Mencari…' : 'Lihat surat'}
          </button>
        </div>
      </form>

      <section className="max-w-2xl mx-auto px-4 pb-20">
        {errorMsg && (
          <p className="text-sm text-airmail bg-airmail/5 border border-airmail/30 rounded px-3 py-2 mb-4">
            {errorMsg}
          </p>
        )}

        {capsules && capsules.length === 0 && (
          <p className="text-center text-ink/60 py-10">
            Belum ada surat untuk email ini. Surat yang kamu tulis akan muncul di sini.
          </p>
        )}

        {capsules && capsules.length > 0 && (
          <ul className="space-y-3">
            {capsules.map((c) => (
              <li
                key={c.id}
                className="bg-envelope border border-line rounded p-4 flex items-center justify-between gap-4"
              >
                <div>
                  <p className="font-semibold text-postal">{c.title || 'Tanpa judul'}</p>
                  <p className="text-sm text-ink/60 mt-0.5">
                    {c.sent
                      ? `Terkirim ${formatDateTime(c.sent_at)}`
                      : `Akan sampai ${formatDateTime(c.scheduled_at)}`}
                  </p>
                </div>
                <span
                  className={`shrink-0 text-xs font-semibold px-3 py-1 rounded-full ${
                    c.sent
                      ? 'bg-stamp/10 text-stamp'
                      : 'bg-postal/10 text-postal'
                  }`}
                >
                  {c.sent ? 'Terkirim' : 'Disegel & menunggu'}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}

export default function CekPage() {
  return (
    <Suspense fallback={null}>
      <CekContent />
    </Suspense>
  );
}
