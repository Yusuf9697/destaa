import { Special_Elite, Source_Serif_4 } from 'next/font/google';
import './globals.css';

const display = Special_Elite({
  weight: '400',
  subsets: ['latin'],
  variable: '--font-display',
  display: 'swap',
});

const serif = Source_Serif_4({
  subsets: ['latin'],
  variable: '--font-serif',
  display: 'swap',
});

export const metadata = {
  title: 'SuratWaktu — Surat untuk Masa Depan',
  description:
    'Tulis surat untuk dirimu sendiri, kirim sejam, sehari, sebulan, atau setahun dari sekarang.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body className={`${display.variable} ${serif.variable} bg-kraft text-ink font-serif antialiased`}>
        {children}
      </body>
    </html>
  );
}
