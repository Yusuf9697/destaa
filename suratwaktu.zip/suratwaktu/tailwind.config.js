/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        kraft: '#EDE6D6',
        envelope: '#FAF7F0',
        ink: '#2B2520',
        postal: '#1B3A5C',
        airmail: '#C1432D',
        stamp: '#3F6B57',
        line: '#ddd5c2',
      },
      fontFamily: {
        display: ['var(--font-display)', 'monospace'],
        serif: ['var(--font-serif)', 'Georgia', 'serif'],
      },
    },
  },
  plugins: [],
};
