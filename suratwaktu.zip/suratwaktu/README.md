# SuratWaktu — Surat untuk Masa Depan

Website untuk menulis surat ke diri sendiri dan menjadwalkannya terkirim
lewat email kapan pun kamu mau: sejam lagi, sehari, sebulan, atau tahunan
dari sekarang.

Ini bukan demo — kalau kamu deploy mengikuti panduan di bawah, ini jadi
website asli yang beneran mengirim email lewat layanan email sungguhan.

## Bagaimana cara kerjanya

1. **Tampilan web** (Next.js) — tempat kamu menulis surat & memilih waktu.
2. **Database** (Supabase) — tempat surat disimpan sampai waktunya tiba.
3. **Penjadwal** (cron-job.org, gratis) — setiap beberapa menit, "mengetuk"
   website ini dan bertanya "ada surat yang sudah waktunya kah?"
4. **Pengirim email** (Resend) — kalau ada surat yang waktunya sudah tiba,
   bagian ini yang benar-benar mengirim emailnya ke kotak masukmu.

Karena pengecekannya dilakukan oleh layanan luar (bukan oleh komputer
kamu), surat tetap akan terkirim tepat waktu walaupun laptop kamu mati,
bahkan kalau jadwalnya tahun depan.

## Yang kamu butuhkan (semua gratis)

- Akun [Vercel](https://vercel.com) — untuk meng-host website
- Akun [Supabase](https://supabase.com) — database
- Akun [Resend](https://resend.com) — pengirim email
- Akun [cron-job.org](https://cron-job.org) — penjadwal
- Akun GitHub (untuk menghubungkan kode ke Vercel)

---

## Langkah 1 — Siapkan database di Supabase

1. Buat project baru di [supabase.com](https://supabase.com) (pilih region
   terdekat, misalnya Singapore).
2. Setelah project siap, buka menu **SQL Editor** → **New query**.
3. Buka file `supabase-schema.sql` di project ini, copy semua isinya, paste
   ke SQL Editor, lalu klik **Run**. Ini membuat tabel `capsules` tempat
   semua surat disimpan.
4. Buka **Settings → API**. Catat dua hal ini, akan dipakai di Langkah 4:
   - **Project URL** → ini jadi `SUPABASE_URL`
   - **service_role key** (bukan `anon` key) → ini jadi `SUPABASE_SERVICE_ROLE_KEY`

## Langkah 2 — Siapkan pengirim email di Resend

1. Daftar di [resend.com](https://resend.com) lalu buka **API Keys** →
   buat API key baru. Catat nilainya → ini jadi `RESEND_API_KEY`.
2. Untuk mulai cepat, kamu bisa kirim pakai alamat bawaan
   `onboarding@resend.dev` tanpa setup tambahan — cocok untuk coba-coba.
3. Untuk pemakaian jangka panjang (apalagi kalau ada surat yang dijadwalkan
   bertahun-tahun ke depan), sebaiknya verifikasi domain emailmu sendiri di
   menu **Domains** supaya pengiriman lebih stabil dan tidak masuk folder
   spam. Resend akan memandu proses verifikasinya (tambah beberapa DNS
   record di penyedia domainmu).
4. Resend punya batas kirim gratis per hari/bulan — cek halaman **Pricing**
   di dashboard Resend untuk angka terkininya.

## Langkah 3 — Push kode ini ke GitHub

1. Buat repository baru (boleh private) di GitHub.
2. Upload/push semua file di folder project ini ke repository tersebut.

## Langkah 4 — Deploy ke Vercel

1. Di [vercel.com](https://vercel.com), klik **Add New → Project**, lalu
   pilih repository GitHub yang baru kamu buat.
2. Sebelum klik Deploy, buka bagian **Environment Variables** dan isi:

   | Nama | Isi |
   |---|---|
   | `SUPABASE_URL` | Project URL dari Langkah 1 |
   | `SUPABASE_SERVICE_ROLE_KEY` | service_role key dari Langkah 1 |
   | `RESEND_API_KEY` | API key dari Langkah 2 |
   | `EMAIL_FROM` | `SuratWaktu <onboarding@resend.dev>` (atau alamat domainmu) |
   | `CRON_SECRET` | string acak yang panjang, buat sendiri (lihat catatan di bawah) |

   Untuk `CRON_SECRET`, buat string acak misalnya lewat
   `https://1password.com/password-generator` — jangan dibagikan ke siapa
   pun, karena ini "kunci" yang melindungi endpoint pengirim email supaya
   tidak bisa dipicu sembarang orang.

3. Klik **Deploy**. Setelah selesai, kamu akan dapat URL seperti
   `https://suratwaktu-kamu.vercel.app`.

## Langkah 5 — Nyalakan penjadwal di cron-job.org

Ini langkah yang membuat surat benar-benar terkirim otomatis.

1. Daftar gratis di [cron-job.org](https://cron-job.org).
2. Klik **Create cronjob**.
3. Di kolom **URL**, isi:

   ```
   https://suratwaktu-kamu.vercel.app/api/cron?secret=ISI_CRON_SECRET_KAMU
   ```

   (ganti `suratwaktu-kamu.vercel.app` dengan domain Vercel kamu, dan
   `ISI_CRON_SECRET_KAMU` dengan nilai `CRON_SECRET` yang kamu isi di
   Langkah 4)

4. Atur **Execution schedule** ke setiap 10–15 menit.
5. Simpan dan aktifkan cronjob-nya.

Selesai! Sekarang setiap 10–15 menit, cron-job.org akan mengetuk website
kamu dan mengirim semua surat yang sudah waktunya — baik itu sejam lagi
atau lima tahun lagi.

## Cara pakai website-nya

- Buka domain Vercel kamu → tulis surat → pilih kapan surat harus sampai →
  klik **Segel & kirim ke masa depan**.
- Buka halaman **/cek** untuk melihat status semua surat yang pernah kamu
  tulis dengan email yang sama (terkirim / masih menunggu).

## Catatan privasi

Halaman **/cek** mencari surat hanya berdasarkan alamat email, tanpa kata
sandi. Ini cukup untuk pemakaian pribadi/santai, tapi siapa pun yang tahu
emailmu bisa melihat judul dan waktu surat (bukan isinya — isi surat tidak
ditampilkan di halaman itu). Kalau kamu butuh privasi lebih ketat, ini
adalah hal pertama yang sebaiknya ditambahkan (misalnya pakai kode unik
atau login).

## Menjalankan di komputer sendiri (opsional, untuk coba-coba sebelum deploy)

```bash
npm install
cp .env.local.example .env.local
# isi .env.local dengan nilai dari Langkah 1 & 2 di atas
npm run dev
```

Buka `http://localhost:3000`. Catatan: di localhost, endpoint `/api/cron`
tidak akan otomatis terpanggil (karena cron-job.org butuh URL publik) —
kamu bisa mengetes pengiriman manual dengan membuka di browser:
`http://localhost:3000/api/cron?secret=isi-CRON_SECRET-kamu`.
