-- Jalankan file ini di Supabase: buka project kamu -> SQL Editor -> New query
-- -> paste semua isi file ini -> klik Run.

create extension if not exists "pgcrypto";

create table if not exists capsules (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  title text,
  message text not null,
  scheduled_at timestamptz not null,
  created_at timestamptz not null default now(),
  sent boolean not null default false,
  sent_at timestamptz
);

-- Mempercepat pencarian surat yang sudah waktunya dikirim.
create index if not exists capsules_due_idx
  on capsules (scheduled_at)
  where sent = false;

-- Mempercepat halaman "cek surat saya" yang mencari berdasarkan email.
create index if not exists capsules_email_idx
  on capsules (email);
